import { Home, Users, FileText } from "lucide-react";

const menu = [
  { label: "홈", href: "/", icon: Home },
  { label: "훈련사", href: "/trainers", icon: Users },
  { label: "장소", href: "/locations", icon: FileText }
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-gray-50 dark:bg-gray-900 border-r dark:border-gray-700 p-4">
      <div className="font-bold text-lg text-brand-blue mb-6">TALEZ</div>
      <ul className="space-y-4">
        {menu.map(({ label, href, icon: Icon }) => (
          <li key={label}>
            <a href={href} className="flex items-center gap-3 text-gray-700 dark:text-white hover:text-brand-blue">
              <Icon className="w-5 h-5" /> {label}
            </a>
          </li>
        ))}
      </ul>
    </aside>
  );
}