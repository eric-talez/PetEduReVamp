import { ThemeToggle } from "./ui/ThemeToggle";

export default function TopBar() {
  return (
    <header className="flex items-center justify-between px-6 py-4 bg-white dark:bg-gray-800 shadow">
      <h1 className="text-xl font-bold text-brand-blue">TALEZ</h1>
      <div className="flex items-center gap-4">
        <ThemeToggle />
      </div>
    </header>
  );
}